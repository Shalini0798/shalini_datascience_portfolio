from gettext import npgettext
from flask import Flask, escape, request, render_template
import pickle

app = Flask(__name__)
model = pickle.load(open('model_pickle.pkl','rb'))

@app.route('/')
def home():
    return render_template('index.html')


@app.route('/predict', methods=['GET','POST'])

def predict():
    if request.method == 'POST':
        product_code = request.form['product_code']
        business_type = request.form['business_type']
        business_activity = request.form['business_activity']
        BusinFormalityOfTheBusinessui = request.form['BusinFormalityOfTheBusinessui']
        ManagCBscoreui_APP = float(request.form['ManagCBscoreui_APP'])
        
        # product type
        if (product_code == "U"):
            product_u = 1
        else:
            product_u = 0

        #business type
        if (business_type == "Services"):
            busi_service = 1
            busi_trading = 0
        elif (business_type == "Trading"):
            busi_service = 0
            busi_trading = 1
        else:
            busi_service = 0
            busi_trading = 0

        #business activity
        if (business_activity == " Job work and sales"):
            jobwork_and_sales = 1
            retail = 0
            retail_busitobusi = 0
            retail_busitocus = 0
            sales = 0
            wholesale = 0
        elif (business_activity == " Retail"):
            jobwork_and_sales = 0
            retail = 1
            retail_busitobusi = 0
            retail_busitocus = 0
            sales = 0
            wholesale = 0
        elif (business_activity == "Retail(business to business)"):
            jobwork_and_sales = 0
            retail = 0
            retail_busitobusi = 1
            retail_busitocus = 0
            sales = 0
            wholesale = 0
        elif (business_activity == "Retail(business to Customer)"):
            jobwork_and_sales = 0
            retail = 0
            retail_busitobusi = 0
            retail_busitocus = 1
            sales = 0
            wholesale = 0
        elif (business_activity == "Sales"):
            jobwork_and_sales = 0
            retail = 0
            retail_busitobusi = 0
            retail_busitocus = 0
            sales = 1
            wholesale = 0
        elif (business_activity == "Wholesale"):
            jobwork_and_sales = 0
            retail = 0
            retail_busitobusi = 0
            retail_busitocus = 0
            sales = 0
            wholesale = 1
        else:
            jobwork_and_sales = 0
            retail = 0
            retail_busitobusi = 0
            retail_busitocus = 0
            sales = 0
            wholesale = 0
        
        #Formality of business
        if (BusinFormalityOfTheBusinessui == "Cash and Non Banked"):
            cash_and_nonbanked = 1
            invoice_and_banked = 0
            invoice_and_nonbanked = 0
        elif (BusinFormalityOfTheBusinessui == "Invoice and Banked"):
            cash_and_nonbanked = 0
            invoice_and_banked = 1
            invoice_and_nonbanked = 0 
        elif (BusinFormalityOfTheBusinessui == "Invoice and Non Banked"):
            cash_and_nonbanked = 0
            invoice_and_banked = 0
            invoice_and_nonbanked = 1
        else:
            cash_and_nonbanked = 0
            invoice_and_banked = 0
            invoice_and_nonbanked = 0  

    
        prediction = model.predict([[ ManagCBscoreui_APP, product_u, busi_service , busi_trading, jobwork_and_sales, retail,
        retail_busitobusi, retail_busitocus, sales, wholesale, cash_and_nonbanked,
        invoice_and_banked, invoice_and_nonbanked ]])

        #pridiction print

        if (prediction == 0):
            prediction = 'Rejected'
        else:
            prediction = 'Approved'
        print(prediction)
        return render_template ("Prediction.html", prediction_text="Your loan request is" + " " + prediction)


         
    else:
        return render_template('prediction.html')


if __name__ ==  "__main__":
    app.run(debug=True)

